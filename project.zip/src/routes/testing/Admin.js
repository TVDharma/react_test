import Counter from "./Counter";
import { Provider } from "react-redux";
import store from "./store";


const Admin = () => {
    return <div>
        <Provider store={store}>
        <Counter />
        </Provider>
    </div>
}

export default Admin;