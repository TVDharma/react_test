import { createSlice, configureStore} from "@reduxjs/toolkit";
import watchAPI from "./saga";
import createSagaMiddleware from 'redux-saga';

const sagaMiddleware = createSagaMiddleware()
const middleware = [sagaMiddleware]

const countSlice = createSlice({
    name: 'countSlice',
    initialState: {countValue: 0, resultData: {}},
    reducers: {
        increseCounter(state, payload){
            // state.countValue += 1; 
            console.log(state);
        },
        decreseCounter(state, payload){
            state.countValue -= 1; 
        },
        result(state, payload){
            console.log(payload);
            state.resultData = payload.payload;
            state.countValue += 1;
        }        
    }

});

export const {increseCounter, decreseCounter, result} = countSlice.actions;

const store = configureStore({
    reducer: countSlice.reducer,
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(middleware),
});

sagaMiddleware.run(watchAPI);

export default store;