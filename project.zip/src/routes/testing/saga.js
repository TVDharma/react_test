import {call, takeEvery, put} from 'redux-saga/effects';
import {result, increseCounter} from './store';

function* callAPI(){
    const api = yield call(fetch, 'https://fakestoreapi.com/products/1');
    const response = yield api.json();
    yield put(result(response));
}

function* watchAPI(){
    yield takeEvery(increseCounter, callAPI);
}

export default watchAPI;