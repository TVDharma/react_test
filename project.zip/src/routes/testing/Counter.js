// import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { increseCounter, decreseCounter } from "./store";
const Counter = () => {
    const state = useSelector(state => state);
    console.log(state);
    const dispatch = useDispatch();
    function handleIncreClick(){
        dispatch(increseCounter(1));
    }
    function handleDecClick(){
        dispatch(decreseCounter());
    }
    // const [] = useState();
    return <div>
        <p><button type="button" data-testid="counter" onClick={handleIncreClick}>+</button></p>
        <p data-testid="countData">{state.countValue}</p>
        <p><button type="button" onClick={handleDecClick}>-</button></p>
        {/* {state.resultData.length >= 1 && <ul>
        {state.resultData.map((result)=>{
            return <li key={result.id}>{result.title}</li>
        })}
        </ul>} */}
        <ul>
            <li data-testid="title">{state.resultData.title}</li>
            <li data-testid="description">{state.resultData.description}</li>
        </ul>
    </div>
}
export default Counter;