function TestRoute() {
  return <div>TestRoute</div>;
}

export default TestRoute;
