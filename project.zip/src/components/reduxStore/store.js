import { createSlice, configureStore } from "@reduxjs/toolkit";
import { number } from "prop-types";

const testingSlice = createSlice({
    name: 'testingSlice',
    initialState: {number:0},
    reducers: {
        getValue(){
            return number;
        }
    }
});

export  const {getValue} = testingSlice.actions;

const store = configureStore({
    reducer: testingSlice.reducer
});

export default store;