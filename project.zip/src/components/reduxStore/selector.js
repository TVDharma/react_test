// import { createSelector } from "@reduxjs/toolkit";

export const get = (state) => state