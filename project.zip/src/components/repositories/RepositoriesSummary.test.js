import { render, screen } from "@testing-library/react";
import user from '@testing-library/user-event';
import RepositoriesSummary from "./RepositoriesSummary";

test("show language it in the screen", () => {
    const repository = {
        language: 'python',
        stargazers_count: '120',
        // open_issues: '1',
        forks: '100'
    }
    //load data
    render(<RepositoriesSummary repository={repository}/>);

    //action
    // const lang = screen.getByText('python');

    // expect(lang).toBeInTheDocument();

    for(let key in repository){
        const value = repository[key];
        const ele = screen.getByText(new RegExp(value));

        expect(ele).toBeInTheDocument();
    }

});